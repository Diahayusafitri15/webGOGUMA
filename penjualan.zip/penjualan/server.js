const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Konfigurasi view engine EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));

// Data produk (sementara, tanpa database)
let products = [
    {
      id: 1,
      name: "Goguma Cheese",
      price: 25000,
      image: "/images/cheese cake.jpg",
      description: "Roti panggang dengan isian ubi ungu dan keju leleh, gurih dan manis berpadu sempurna."
    },
    {
      id: 2,
      name: "Goguma Ori",
      price: 20000,
      image: "/images/guguma.jpg",
      description: "Kue lembut berbahan dasar ubi ungu asli, sehat, manis alami, dan cocok untuk semua usia."
    },
    {
      id: 3,
      name: "Goguma Crispi",
      price: 18000,
      image: "/images/crispi.jpg",
      description: "Potongan ubi ungu goreng renyah dengan balutan tepung crispy, cocok jadi camilan sore."
    }
  ];
  
// Route utama (menampilkan daftar produk)
app.get("/", (req, res) => {
  res.render("index", { products });
});

// Route form tambah produk
app.get("/add", (req, res) => {
  res.render("add");
});

// Route untuk menambah produk baru
app.post("/add", (req, res) => {
  const { name, price, image } = req.body;
  const newProduct = {
    id: products.length + 1,
    name,
    price: parseInt(price),
    image // pastikan sesuai path gambar di /public/images
  };
  products.push(newProduct);
  res.redirect("/");
});

// Jalankan server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
